import os
from langchain_groq import ChatGroq
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.exceptions import OutputParserException
from dotenv import load_dotenv

load_dotenv()

class Chain:
    def __init__(self):
        self.llm = ChatGroq(temperature=0, groq_api_key=os.getenv("GROQ_API_KEY"), model_name="openai/gpt-oss-120b")

    def extract_jobs(self, cleaned_text):
        prompt_extract = PromptTemplate.from_template(
            """
            ### SCRAPED TEXT FROM WEBSITE:
            {page_data}
            ### INSTRUCTION:
            The scraped text is from the career's page of a website.
            Your job is to extract the job postings and return them in JSON format containing the following keys: `role`, `experience`, `skills` and `description`.
            Only return the valid JSON.
            ### VALID JSON (NO PREAMBLE):
            """
        )
        chain_extract = prompt_extract | self.llm
        res = chain_extract.invoke(input={"page_data": cleaned_text})
        try:
            json_parser = JsonOutputParser()
            res = json_parser.parse(res.content)
        except OutputParserException:
            raise OutputParserException("Context too big. Unable to parse jobs.")
        return res if isinstance(res, list) else [res]

    def write_mail(self, job, links):
        prompt_email = PromptTemplate.from_template(
            """
            ### JOB DESCRIPTION:
            {job_description}

            ### INSTRUCTION:
            You are Suraj Ahirwar, an M.Tech student in Computer Science and Engineering at the
            Indian Institute of Technology, Indore (CGPA 9.23), with hands-on experience across
            machine learning, embedded systems, and full-stack web development.
            Key Projects:

            Automated Human Eye Disease Detection System: A machine learning-based image classification system that detects retinal diseases from fundus images, using a pre-trained ResNet-50 CNN (transfer learning) for feature extraction and a Random Forest classifier for multi-class disease prediction.
            GSM-DTMF Controlled 4-Wheel Robot: A GSM-based remote-controlled robotic vehicle using DTMF signal decoding, built with an Arduino UNO, MT8870 DTMF decoder, and embedded C/C++ control logic for real-time motor control.
            Online News Portal Website: A full-stack web application built with Node.js and JavaScript, featuring REST API integration for real-time news fetching and dynamic content rendering.

            Additional strengths: strong DSA fundamentals (250+ LeetCode, 150+ GeeksforGeeks problems solved),
            a GATE 2025 CSE score of 568/1000, and coursework spanning data structures, DBMS, operating systems,
            computer networks, and microprocessors.
            Your job is to write a cold email to the recruiter regarding the job mentioned above describing the capability me 
            in fulfilling their needs.
            Also add the most relevant ones from the following links to showcase Suraj's portfolio: {link_list}
            Remember you are Suraj Ahirwar, an M.Tech CSE student at IIT Indore. 

            STRICT ACCURACY RULES - follow these exactly:
            - Only mention skills, tools, and technologies that are explicitly listed above. Do NOT invent, assume, or add
              any technology, framework, or experience that is not explicitly stated (for example, do not say "Kafka",
              "Go", "ClickHouse", "distributed systems", or "D3.js" unless those exact words appear above).
            - If a project used Node.js and JavaScript, describe it using only Node.js and JavaScript - do not upgrade it
              with unrelated buzzwords to sound more impressive.
            - It is fine, and expected, to honestly acknowledge gaps: emphasize genuine transferable strengths
              (DSA fundamentals, ML experience, fast learner, coursework) rather than fabricating a direct skill match.
            - Do not include placeholder text like "[Recruiter's Name]" or a fake phone number. Skip the phone number
              entirely and open with a generic, professional greeting like "Hi there," or "Hello," instead.
            - Do not use markdown formatting such as **bold** or bullet symbols like - or *. Write the email as
              plain text with normal paragraphs, since it will be sent as a plain-text email.
            Do not provide a preamble.
            ### EMAIL (NO PREAMBLE):

            """
        )
        chain_email = prompt_email | self.llm
        res = chain_email.invoke({"job_description": str(job), "link_list": links})
        return res.content

if __name__ == "__main__":
    print(os.getenv("GROQ_API_KEY"))
